
import React from 'react';
import { MessageSquare, Lightbulb, Rocket } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const HowItWorksSection: React.FC = () => {
  const { t, isRTL } = useLanguage();

  const steps = [
    {
      icon: MessageSquare,
      titleKey: 'step1Title',
      descKey: 'step1Desc',
      number: '01'
    },
    {
      icon: Lightbulb,
      titleKey: 'step2Title',
      descKey: 'step2Desc',
      number: '02'
    },
    {
      icon: Rocket,
      titleKey: 'step3Title',
      descKey: 'step3Desc',
      number: '03'
    }
  ];

  return (
    <section id="how-it-works" className="section-padding bg-white">
      <div className="container mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6 ${isRTL ? 'font-arabic' : 'font-english'}`}>
            {t('howItWorksTitle')}
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-brand-blue-500 to-brand-teal-500 mx-auto rounded-full"></div>
        </div>

        {/* Steps Timeline */}
        <div className="relative">
          {/* Desktop Timeline Line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-brand-blue-500 to-brand-teal-500 transform -translate-y-1/2"></div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
            {steps.map((step, index) => (
              <div
                key={step.titleKey}
                className={`relative animate-fade-in ${isRTL ? 'text-right' : 'text-left'}`}
                style={{ animationDelay: `${index * 0.3}s` }}
              >
                {/* Desktop Timeline Dot */}
                <div className="hidden lg:block absolute top-1/2 left-1/2 w-6 h-6 bg-gradient-to-br from-brand-blue-500 to-brand-teal-500 rounded-full transform -translate-x-1/2 -translate-y-1/2 z-10"></div>

                {/* Card */}
                <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 lg:-translate-y-12 group">
                  {/* Step Number */}
                  <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-blue-50 to-brand-teal-50 mb-6 ${isRTL ? 'mr-0 ml-auto' : ''}`}>
                    <span className="text-2xl font-bold gradient-text">{step.number}</span>
                  </div>

                  {/* Icon */}
                  <div className={`w-12 h-12 text-brand-blue-600 mb-4 group-hover:scale-110 transition-transform duration-300 ${isRTL ? 'mr-0 ml-auto' : ''}`}>
                    <step.icon className="w-full h-full" />
                  </div>

                  {/* Content */}
                  <h3 className={`text-xl font-bold text-gray-900 mb-4 ${isRTL ? 'font-arabic' : 'font-english'}`}>
                    {t(step.titleKey)}
                  </h3>
                  
                  <p className={`text-gray-600 leading-relaxed ${isRTL ? 'font-arabic' : 'font-english'}`}>
                    {t(step.descKey)}
                  </p>
                </div>

                {/* Mobile Timeline Connector */}
                {index < steps.length - 1 && (
                  <div className="lg:hidden flex justify-center my-8">
                    <div className="w-0.5 h-12 bg-gradient-to-b from-brand-blue-500 to-brand-teal-500"></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
