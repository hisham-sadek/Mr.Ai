
import React from 'react';
import { Bot, TrendingUp, BarChart3, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';

const ServicesSection: React.FC = () => {
  const { t, isRTL } = useLanguage();

  const services = [
    {
      icon: Bot,
      titleKey: 'aiAutomation',
      descKey: 'aiAutomationDesc',
      gradient: 'from-brand-blue-500 to-brand-blue-600',
      bgGradient: 'from-brand-blue-50 to-brand-blue-100'
    },
    {
      icon: TrendingUp,
      titleKey: 'digitalMarketing',
      descKey: 'digitalMarketingDesc',
      gradient: 'from-brand-teal-500 to-brand-teal-600',
      bgGradient: 'from-brand-teal-50 to-brand-teal-100'
    },
    {
      icon: BarChart3,
      titleKey: 'dataAnalysis',
      descKey: 'dataAnalysisDesc',
      gradient: 'from-purple-500 to-purple-600',
      bgGradient: 'from-purple-50 to-purple-100'
    }
  ];

  return (
    <section id="services" className="section-padding bg-gray-50">
      <div className="container mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6 ${isRTL ? 'font-arabic' : 'font-english'}`}>
            {t('servicesTitle')}
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-brand-blue-500 to-brand-teal-500 mx-auto rounded-full"></div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card
              key={service.titleKey}
              className={`hover-lift border-none shadow-lg group animate-fade-in bg-white`}
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <CardHeader className="text-center pb-4">
                <div className={`w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br ${service.bgGradient} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <service.icon className={`w-10 h-10 bg-gradient-to-br ${service.gradient} bg-clip-text text-transparent`} />
                </div>
                <CardTitle className={`text-2xl font-bold text-gray-900 mb-3 ${isRTL ? 'font-arabic' : 'font-english'}`}>
                  {t(service.titleKey)}
                </CardTitle>
              </CardHeader>
              
              <CardContent className="text-center">
                <CardDescription className={`text-gray-600 text-lg mb-6 leading-relaxed ${isRTL ? 'font-arabic' : 'font-english'}`}>
                  {t(service.descKey)}
                </CardDescription>
                
                <Button
                  variant="ghost"
                  className={`text-brand-blue-600 hover:text-brand-blue-700 hover:bg-brand-blue-50 group-hover:shadow-md transition-all duration-300 ${isRTL ? 'flex-row-reverse' : ''}`}
                >
                  <span className="font-semibold">{t('learnMore')}</span>
                  <ArrowRight className={`w-4 h-4 group-hover:translate-x-1 transition-transform ${isRTL ? 'rotate-180 group-hover:-translate-x-1 mr-2 ml-0' : 'ml-2'}`} />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
