
import React, { useState } from 'react';
import { Menu, X, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { language, setLanguage, t, isRTL } = useLanguage();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const toggleLanguage = () => setLanguage(language === 'en' ? 'ar' : 'en');

  const navItems = [
    { key: 'home', href: '#home' },
    { key: 'services', href: '#services' },
    { key: 'howItWorks', href: '#how-it-works' },
    { key: 'testimonials', href: '#testimonials' },
    { key: 'contactUs', href: '#contact' }
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className={`flex items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
            <button 
              onClick={() => scrollToSection('#home')}
              className="text-2xl font-bold gradient-text hover:scale-105 transition-transform"
            >
              Mr.Ai
            </button>
          </div>

          {/* Desktop Navigation & Language Toggle */}
          <div className={`hidden md:flex items-center space-x-8 ${isRTL ? 'space-x-reverse' : ''}`}>
            <nav className={`flex items-center space-x-6 ${isRTL ? 'space-x-reverse' : ''}`}>
              {navItems.map((item) => (
                <button
                  key={item.key}
                  onClick={() => scrollToSection(item.href)}
                  className="text-gray-700 hover:text-brand-blue-600 transition-colors duration-200 font-medium"
                >
                  {t(item.key)}
                </button>
              ))}
            </nav>
            
            <Button
              variant="outline"
              size="sm"
              onClick={toggleLanguage}
              className={`flex items-center space-x-2 ${isRTL ? 'space-x-reverse' : ''}`}
            >
              <Globe className="w-4 h-4" />
              <span>{language === 'en' ? 'عربي' : 'EN'}</span>
            </Button>
          </div>

          {/* Mobile Menu Button & Language Toggle */}
          <div className={`md:hidden flex items-center space-x-4 ${isRTL ? 'space-x-reverse' : ''}`}>
            <Button
              variant="ghost"
              size="sm"  
              onClick={toggleLanguage}
              className="text-gray-700"
            >
              {language === 'en' ? 'عربي' : 'EN'}
            </Button>
            
            <button
              onClick={toggleMenu}
              className="text-gray-700 hover:text-brand-blue-600 transition-colors"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMenuOpen && (
        <div className="md:hidden fixed inset-0 top-16 bg-white z-40 animate-slide-down">
          <nav className="flex flex-col items-center space-y-8 py-12">
            {navItems.map((item) => (
              <button
                key={item.key}
                onClick={() => scrollToSection(item.href)}
                className="text-xl text-gray-700 hover:text-brand-blue-600 transition-colors duration-200 font-medium"
              >
                {t(item.key)}
              </button>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
