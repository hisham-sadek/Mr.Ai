
import React from 'react';
import { Mail, Phone, MapPin, Facebook, Twitter, Linkedin, Instagram, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';

const Footer: React.FC = () => {
  const { language, setLanguage, t, isRTL } = useLanguage();

  const toggleLanguage = () => setLanguage(language === 'en' ? 'ar' : 'en');

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Instagram, href: '#', label: 'Instagram' }
  ];

  const quickLinks = [
    { key: 'home', href: '#home' },
    { key: 'services', href: '#services' },
    { key: 'howItWorks', href: '#how-it-works' },
    { key: 'testimonials', href: '#testimonials' }
  ];

  const legalLinks = [
    { key: 'termsLink', href: '#' },
    { key: 'privacyLink', href: '#' },
    { key: 'contactLink', href: '#contact' }
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="contact" className="bg-brand-gray-900 text-white">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 ${isRTL ? 'text-right' : 'text-left'}`}>
          
          {/* Company Info */}
          <div className="lg:col-span-2">
            <h3 className="text-3xl font-bold gradient-text mb-4">Mr.Ai</h3>
            <p className={`text-gray-300 text-lg leading-relaxed mb-6 max-w-md ${isRTL ? 'font-arabic' : 'font-english'}`}>
              {isRTL 
                ? 'نقدم حلول الذكاء الاصطناعي والأتمتة والتسويق الرقمي للشركات في اليمن والمنطقة.'
                : 'Providing AI automation, digital marketing, and data analysis solutions for businesses across Yemen and beyond.'
              }
            </p>

            {/* Contact Info */}
            <div className="space-y-3">
              <div className={`flex items-center space-x-3 ${isRTL ? 'space-x-reverse flex-row-reverse' : ''}`}>
                <MapPin className="w-5 h-5 text-brand-teal-400 flex-shrink-0" />
                <span className="text-gray-300">{t('footerAddress')}</span>
              </div>
              <div className={`flex items-center space-x-3 ${isRTL ? 'space-x-reverse flex-row-reverse' : ''}`}>
                <Mail className="w-5 h-5 text-brand-teal-400 flex-shrink-0" />
                <a href="mailto:hello@mrai.ye" className="text-gray-300 hover:text-brand-teal-400 transition-colors">
                  {t('footerEmail')}
                </a>
              </div>
              <div className={`flex items-center space-x-3 ${isRTL ? 'space-x-reverse flex-row-reverse' : ''}`}>
                <Phone className="w-5 h-5 text-brand-teal-400 flex-shrink-0" />
                <a href="tel:+967123456789" className="text-gray-300 hover:text-brand-teal-400 transition-colors">
                  {t('footerPhone')}
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className={`text-xl font-semibold mb-6 ${isRTL ? 'font-arabic' : 'font-english'}`}>
              {isRTL ? 'روابط سريعة' : 'Quick Links'}
            </h4>
            <nav className="space-y-3">
              {quickLinks.map((link) => (
                <button
                  key={link.key}
                  onClick={() => scrollToSection(link.href)}
                  className={`block text-gray-300 hover:text-brand-teal-400 transition-colors ${isRTL ? 'font-arabic text-right w-full' : 'font-english text-left'}`}
                >
                  {t(link.key)}
                </button>
              ))}
            </nav>
          </div>

          {/* Legal & Language */}
          <div>
            <h4 className={`text-xl font-semibold mb-6 ${isRTL ? 'font-arabic' : 'font-english'}`}>
              {isRTL ? 'قانوني' : 'Legal'}
            </h4>
            <nav className="space-y-3 mb-6">
              {legalLinks.map((link) => (
                <button
                  key={link.key}
                  onClick={() => scrollToSection(link.href)}
                  className={`block text-gray-300 hover:text-brand-teal-400 transition-colors ${isRTL ? 'font-arabic text-right w-full' : 'font-english text-left'}`}
                >
                  {t(link.key)}
                </button>
              ))}
            </nav>

            {/* Language Toggle */}
            <Button
              variant="outline"
              size="sm"
              onClick={toggleLanguage}
              className={`border-brand-teal-400 text-brand-teal-400 hover:bg-brand-teal-400 hover:text-white transition-colors flex items-center space-x-2 ${isRTL ? 'space-x-reverse' : ''}`}
            >
              <Globe className="w-4 h-4" />
              <span>{language === 'en' ? 'عربي' : 'EN'}</span>
            </Button>
          </div>
        </div>

        {/* Social Media Links */}
        <div className="border-t border-gray-700 pt-8 mt-12">
          <div className={`flex flex-col sm:flex-row items-center justify-between ${isRTL ? 'sm:flex-row-reverse' : ''}`}>
            <div className={`flex items-center space-x-6 mb-4 sm:mb-0 ${isRTL ? 'space-x-reverse' : ''}`}>
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="text-gray-400 hover:text-brand-teal-400 transition-colors hover:scale-110 transform duration-200"
                  aria-label={social.label}
                >
                  <social.icon className="w-6 h-6" />
                </a>
              ))}
            </div>

            <p className={`text-gray-400 text-sm ${isRTL ? 'font-arabic' : 'font-english'}`}>
              {isRTL 
                ? '© 2024 Mr.Ai. جميع الحقوق محفوظة.'
                : '© 2024 Mr.Ai. All rights reserved.'
              }
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
