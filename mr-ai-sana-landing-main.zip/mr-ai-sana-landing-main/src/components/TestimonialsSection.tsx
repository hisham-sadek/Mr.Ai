
import React from 'react';
import { Star, Quote } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';

const TestimonialsSection: React.FC = () => {
  const { t, isRTL } = useLanguage();

  const testimonials = [
    {
      name: 'Ahmed Al-Mansouri',
      title: 'CEO',
      company: 'TechYemen',
      avatar: '👨🏻‍💼',
      rating: 5,
      testimonial: {
        en: 'Mr.Ai transformed our business operations with their AI automation solutions. Our efficiency increased by 300%.',
        ar: 'لقد غيرت Mr.Ai عمليات أعمالنا بحلول الأتمتة الذكية. زادت كفاءتنا بنسبة 300%.'
      }
    },
    {
      name: 'Sarah Abdullah',
      title: 'Marketing Director',
      company: 'GrowthCorp',
      avatar: '👩🏻‍💼',
      rating: 5,
      testimonial: {
        en: 'Their digital marketing strategies doubled our online presence and lead generation within 3 months.',
        ar: 'ضاعفت استراتيجياتهم التسويقية الرقمية حضورنا الإلكتروني وتوليد العملاء المحتملين خلال 3 أشهر.'
      }
    },
    {
      name: 'Mohammed Al-Hadhrami',
      title: 'Operations Manager',
      company: 'DataFlow Solutions',
      avatar: '👨🏽‍💼',
      rating: 5,
      testimonial: {
        en: 'The data analysis dashboards provided insights we never knew existed. Game-changing for our decision making.',
        ar: 'قدمت لوحات تحليل البيانات رؤى لم نكن نعلم بوجودها. غيرت قواعد اتخاذ القرارات لدينا.'
      }
    },
    {
      name: 'Fatima Al-Zahra',
      title: 'Founder',
      company: 'InnovateTech',
      avatar: '👩🏻‍💻',
      rating: 5,
      testimonial: {
        en: 'Professional, reliable, and innovative. Mr.Ai exceeded our expectations in every aspect of the project.',
        ar: 'مهنية وموثوقة ومبدعة. تجاوزت Mr.Ai توقعاتنا في كل جانب من جوانب المشروع.'
      }
    }
  ];

  return (
    <section id="testimonials" className="section-padding bg-white">
      <div className="container mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6 ${isRTL ? 'font-arabic' : 'font-english'}`}>
            {t('testimonialsTitle')}
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-brand-blue-500 to-brand-teal-500 mx-auto rounded-full"></div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className={`border-none shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br from-white to-gray-50 animate-fade-in`}
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <CardContent className="p-8">
                {/* Quote Icon */}
                <div className={`mb-6 ${isRTL ? 'text-right' : 'text-left'}`}>
                  <Quote className="w-8 h-8 text-brand-blue-400" />
                </div>

                {/* Testimonial Text */}
                <p className={`text-gray-700 text-lg leading-relaxed mb-6 ${isRTL ? 'font-arabic text-right' : 'font-english text-left'}`}>
                  "{testimonial.testimonial[isRTL ? 'ar' : 'en']}"
                </p>

                {/* Rating */}
                <div className={`flex items-center mb-4 ${isRTL ? 'flex-row-reverse justify-end' : 'justify-start'}`}>
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>

                {/* Author Info */}
                <div className={`flex items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-brand-blue-100 to-brand-teal-100 flex items-center justify-center text-2xl mr-4">
                    {testimonial.avatar}
                  </div>
                  <div className={isRTL ? 'text-right mr-4' : ''}>
                    <h4 className={`font-bold text-gray-900 ${isRTL ? 'font-arabic' : 'font-english'}`}>
                      {testimonial.name}
                    </h4>
                    <p className="text-gray-600 text-sm">
                      {testimonial.title} at {testimonial.company}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
