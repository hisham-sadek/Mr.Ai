
import React from 'react';
import { ArrowRight, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';

const CTABanner: React.FC = () => {
  const { t, isRTL } = useLanguage();

  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="section-padding gradient-bg relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-r from-brand-blue-600/20 to-brand-teal-500/20"></div>
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-10 left-10 w-20 h-20 border border-white/20 rounded-full animate-float"></div>
        <div className="absolute bottom-10 right-10 w-16 h-16 border border-white/20 rounded-full animate-float" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/4 w-12 h-12 border border-white/20 rounded-full animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container mx-auto relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          <h2 className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-8 animate-fade-in ${isRTL ? 'font-arabic' : 'font-english'}`}>
            {t('ctaTitle')}
          </h2>

          <Button
            onClick={scrollToContact}
            size="lg"
            variant="secondary"
            className={`bg-white text-brand-blue-600 hover:bg-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105 px-10 py-5 text-xl font-semibold group animate-fade-in ${isRTL ? 'flex-row-reverse' : ''}`}
            style={{ animationDelay: '0.2s' }}
          >
            <Calendar className={`w-6 h-6 group-hover:scale-110 transition-transform ${isRTL ? 'mr-3 ml-0' : 'mr-3'}`} />
            <span>{t('scheduleCall')}</span>
            <ArrowRight className={`w-5 h-5 group-hover:translate-x-1 transition-transform ${isRTL ? 'rotate-180 group-hover:-translate-x-1 mr-2 ml-0' : 'ml-2'}`} />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CTABanner;
