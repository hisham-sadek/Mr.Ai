
import React from 'react';
import { ArrowRight, Play, Zap, TrendingUp, BarChart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';

const HeroSection: React.FC = () => {
  const { t, isRTL } = useLanguage();

  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center bg-gradient-to-br from-brand-blue-50 to-white relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-brand-teal-400/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-brand-blue-400/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }}></div>
        
        {/* Floating Icons */}
        <div className="absolute top-1/4 left-1/4 text-brand-blue-300 animate-float">
          <Zap className="w-8 h-8" />
        </div>
        <div className="absolute top-1/3 right-1/4 text-brand-teal-400 animate-float" style={{ animationDelay: '2s' }}>
          <TrendingUp className="w-6 h-6" />
        </div>
        <div className="absolute bottom-1/3 left-1/3 text-brand-blue-400 animate-float" style={{ animationDelay: '1.5s' }}>
          <BarChart className="w-7 h-7" />
        </div>
      </div>

      <div className="container mx-auto section-padding relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Headline */}
          <h1 className={`text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight animate-fade-in ${isRTL ? 'font-arabic' : 'font-english'}`}>
            {t('heroHeadline')}
          </h1>

          {/* Sub-headline */}
          <p className={`text-xl sm:text-2xl text-gray-600 mb-10 leading-relaxed animate-fade-in ${isRTL ? 'font-arabic' : 'font-english'}`} style={{ animationDelay: '0.2s' }}>
            {t('heroSubheadline')}
          </p>

          {/* CTA Buttons */}
          <div className={`flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 animate-fade-in ${isRTL ? 'sm:flex-row-reverse' : ''}`} style={{ animationDelay: '0.4s' }}>
            <Button
              onClick={scrollToContact}
              size="lg"
              className={`gradient-bg hover:shadow-xl transition-all duration-300 hover:scale-105 px-8 py-4 text-lg font-semibold group ${isRTL ? 'flex-row-reverse' : ''}`}
            >
              <span>{t('getConsultation')}</span>
              <ArrowRight className={`w-5 h-5 group-hover:translate-x-1 transition-transform ${isRTL ? 'rotate-180 group-hover:-translate-x-1 mr-2 ml-0' : 'ml-2'}`} />
            </Button>

            <Button
              variant="outline"
              size="lg"
              className={`border-2 border-brand-blue-500 text-brand-blue-600 hover:bg-brand-blue-50 px-8 py-4 text-lg font-semibold group ${isRTL ? 'flex-row-reverse' : ''}`}
            >
              <Play className={`w-5 h-5 group-hover:scale-110 transition-transform ${isRTL ? 'mr-2 ml-0' : 'mr-2'}`} />
              <span>{t('watchArabic')}</span>
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className={`mt-16 animate-fade-in ${isRTL ? 'font-arabic' : 'font-english'}`} style={{ animationDelay: '0.6s' }}>
            <p className="text-gray-500 mb-8 text-lg">Trusted by businesses in Yemen and beyond</p>
            <div className="flex items-center justify-center space-x-12 opacity-60">
              <div className="text-2xl font-bold text-gray-400">50+</div>
              <div className="text-2xl font-bold text-gray-400">Projects</div>
              <div className="text-2xl font-bold text-gray-400">5★</div>
              <div className="text-2xl font-bold text-gray-400">Rating</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
