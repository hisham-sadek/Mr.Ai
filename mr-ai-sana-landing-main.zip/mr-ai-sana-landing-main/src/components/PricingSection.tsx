
import React from 'react';
import { CheckCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';

const PricingSection: React.FC = () => {
  const { t, isRTL } = useLanguage();

  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="section-padding bg-gradient-to-br from-brand-blue-50 to-white">
      <div className="container mx-auto">
        <div className="max-w-4xl mx-auto">
          <Card className="border-none shadow-2xl bg-white/80 backdrop-blur-sm animate-fade-in">
            <CardHeader className="text-center pb-8">
              <CardTitle className={`text-3xl sm:text-4xl font-bold text-gray-900 mb-6 ${isRTL ? 'font-arabic' : 'font-english'}`}>
                {t('pricingTitle')}
              </CardTitle>
              <div className="w-24 h-1 bg-gradient-to-r from-brand-blue-500 to-brand-teal-500 mx-auto rounded-full mb-8"></div>
            </CardHeader>

            <CardContent className="text-center">
              <p className={`text-xl text-gray-600 mb-8 leading-relaxed max-w-3xl mx-auto ${isRTL ? 'font-arabic' : 'font-english'}`}>
                {t('pricingDesc')}
              </p>

              {/* Features List */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10 max-w-2xl mx-auto">
                {[
                  'Custom solution design',
                  'Scalable implementation',
                  'Ongoing support included',
                  'Performance optimization'
                ].map((feature, index) => (
                  <div
                    key={index}
                    className={`flex items-center space-x-3 ${isRTL ? 'space-x-reverse flex-row-reverse' : ''}`}
                  >
                    <CheckCircle className="w-5 h-5 text-brand-teal-500 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>

              {/* CTA Button */}
              <Button
                onClick={scrollToContact}
                size="lg"
                className={`gradient-bg hover:shadow-xl transition-all duration-300 hover:scale-105 px-8 py-4 text-lg font-semibold group ${isRTL ? 'flex-row-reverse' : ''}`}
              >
                <span>{t('requestQuote')}</span>
                <ArrowRight className={`w-5 h-5 group-hover:translate-x-1 transition-transform ${isRTL ? 'rotate-180 group-hover:-translate-x-1 mr-2 ml-0' : 'ml-2'}`} />
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
