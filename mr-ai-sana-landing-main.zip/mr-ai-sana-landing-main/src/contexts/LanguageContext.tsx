
import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const translations = {
  en: {
    // Navigation
    home: 'Home',
    services: 'Services', 
    howItWorks: 'How It Works',
    testimonials: 'Testimonials',
    contactUs: 'Contact Us',
    
    // Hero Section
    heroHeadline: 'Empower Your Growth with Bespoke AI & Digital Solutions',
    heroSubheadline: 'Custom automation, marketing, and analytics for businesses of every scale.',
    getConsultation: 'Get a Free Consultation',
    watchArabic: 'شاهد العرض بالعربي',
    
    // Services
    servicesTitle: 'Our Services',
    aiAutomation: 'AI Automation',
    aiAutomationDesc: 'Automate workflows, CRM actions, and customer touchpoints with intelligent software agents.',
    digitalMarketing: 'Digital Marketing', 
    digitalMarketingDesc: 'Drive growth with targeted campaigns, SEO optimizations, and social media strategies.',
    dataAnalysis: 'Data Analysis',
    dataAnalysisDesc: 'Unlock insights and forecast trends through real-time data visualization.',
    learnMore: 'Learn More',
    
    // How It Works
    howItWorksTitle: 'How It Works',
    step1Title: 'Consultation & Scope',
    step1Desc: 'We analyze your needs and define project requirements',
    step2Title: 'Custom Solution Design', 
    step2Desc: 'Our experts craft tailored solutions for your business',
    step3Title: 'Deployment & Support',
    step3Desc: 'We implement and provide ongoing maintenance',
    
    // Pricing
    pricingTitle: 'Pricing Tailored to Your Needs',
    pricingDesc: 'We don\'t offer fixed packages. Every quote is custom-built based on your project scope and company size.',
    requestQuote: 'Request a Quote',
    
    // Testimonials
    testimonialsTitle: 'What Our Clients Say',
    
    // CTA Banner
    ctaTitle: 'Ready to Transform Your Business?',
    scheduleCall: 'Schedule a Call',
    
    // Footer
    footerAddress: 'Sana\'a, Yemen',
    footerEmail: 'hello@mrai.ye',
    footerPhone: '+967 123 456 789',
    termsLink: 'Terms',
    privacyLink: 'Privacy',
    contactLink: 'Contact'
  },
  ar: {
    // Navigation
    home: 'الرئيسية',
    services: 'الخدمات',
    howItWorks: 'كيف نعمل',
    testimonials: 'آراء العملاء', 
    contactUs: 'اتصل بنا',
    
    // Hero Section
    heroHeadline: 'نمِّ عملك بحلول الذكاء الاصطناعي والخدمات الرقمية المصممة خصيصًا',
    heroSubheadline: 'أتمتة وتسويق وتحليلات مخصصة لجميع أحجام الأعمال.',
    getConsultation: 'احصل على استشارة مجانية',
    watchArabic: 'View in English',
    
    // Services
    servicesTitle: 'خدماتنا',
    aiAutomation: 'أتمتة الذكاء الاصطناعي',
    aiAutomationDesc: 'أتمتة العمليات ونقاط الاتصال مع العملاء باستخدام وكلاء برمجيين ذكيين.',
    digitalMarketing: 'التسويق الرقمي',
    digitalMarketingDesc: 'نمو الأعمال بحملات مستهدفة، وتحسين محركات البحث، واستراتيجيات التواصل الاجتماعي.',
    dataAnalysis: 'تحليل البيانات',
    dataAnalysisDesc: 'استخلاص الرؤى وتوقع الاتجاهات من خلال تصورات البيانات الفورية.',
    learnMore: 'اعرف المزيد',
    
    // How It Works
    howItWorksTitle: 'كيف نعمل',
    step1Title: 'الاستشارة وتحديد نطاق المشروع',
    step1Desc: 'نحلل احتياجاتك ونحدد متطلبات المشروع',
    step2Title: 'تصميم الحل المناسب',
    step2Desc: 'يقوم خبراؤنا بإنشاء حلول مخصصة لعملك',
    step3Title: 'التنفيذ والدعم المستمر',
    step3Desc: 'ننفذ المشروع ونقدم الصيانة المستمرة',
    
    // Pricing
    pricingTitle: 'أسعار مصممة خصيصًا لاحتياجاتك',
    pricingDesc: 'لا نقدم باقات ثابتة. يتم إعداد كل عرض سعر حسب نطاق المشروع وحجم شركتك.',
    requestQuote: 'اطلب عرض سعر',
    
    // Testimonials
    testimonialsTitle: 'آراء عملائنا',
    
    // CTA Banner
    ctaTitle: 'هل أنت مستعد لتحويل عملك؟',
    scheduleCall: 'احجز مكالمة',
    
    // Footer
    footerAddress: 'صنعاء، اليمن',
    footerEmail: 'hello@mrai.ye',
    footerPhone: '+967 123 456 789',
    termsLink: 'الشروط',
    privacyLink: 'الخصوصية',
    contactLink: 'اتصل بنا'
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  const isRTL = language === 'ar';

  React.useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language, isRTL]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
